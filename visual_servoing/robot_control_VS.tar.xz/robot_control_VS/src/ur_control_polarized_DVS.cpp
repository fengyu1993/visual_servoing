#include "ros_ur_DVS.h"
#include "key.h"
#include <moveit/planning_scene_interface/planning_scene_interface.h>

int main(int argc, char** argv)
{
    // ׼��
    ros::init(argc, argv, "DVS");     
    // ros::AsyncSpinner spinner(1);
    // spinner.start();  
    ROS_INFO("Move to initial pose ... ");
    ROS_INFO("Press Enter to start the experiment ...");
    cin.ignore();
    Ros_ur_DVS DVS_control;
    // ��е���ƶ�����ʼλ��
    DVS_control.control_switcher_.switch_controllers("position", "twist");
    ROS_INFO("Move to initial pose ... ");
    ROS_INFO("Press Enter to start...");
    cin.ignore();
    DVS_control.robot_move_to_target_joint_angle(DVS_control.joint_angle_start_);
    ROS_INFO("Move to initial pose finished ");
    // ��е���ƶ�����ʼ�ŷ�λ��
    ROS_INFO("Move to initial VS pose ... ");
    ROS_INFO("Press Enter to start...");
    cin.ignore();
    DVS_control.robot_move_to_target_joint_angle(DVS_control.joint_angle_initial_VS_);
    // spinner.stop();
    // ת��������
    DVS_control.control_switcher_.switch_controllers("twist", "position");
    // �Ӿ��ŷ�����
    ROS_INFO("Start visual servoing control ... ");
    ROS_INFO("Press Enter to start...");
    cin.ignore();
    DVS_control.start_DVS = true;
    ros::Rate loop_rate(DVS_control.control_rate_);
    int num = 0; 
    while (ros::ok())
    {
        try{
            if(DVS_control.flag_success_){
                ROS_INFO("visual servoing success");
                DVS_control.start_DVS = false;
                break;
            }else{
                ros::spinOnce();
                loop_rate.sleep();
            }
        }catch(...){
            return 1;
        }
    }
    // // ת��������
    // DVS_control.control_switcher_.switch_controllers("position", "twist");
    // // ��е���ƶ�����ʼλ��
    // ROS_INFO("Move to work position ... ");
    // ROS_INFO("Press Enter to start...");
    // cin.ignore();
    // spinner.start();
    // DVS_control.robot_move_to_target_joint_angle(joint_group_positions_start);
    // ����
    return 0;
}

