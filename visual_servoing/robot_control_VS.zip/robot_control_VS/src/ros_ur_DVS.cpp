#include "ros_ur_DVS.h"

Ros_ur_DVS::Ros_ur_DVS(): it_(nh_) 
{
    // ���÷ֱ���
    int resolution_x, resolution_y;
    get_parameters_resolution(resolution_x, resolution_y);
    // ��ʼ��
    this->DVS = new Direct_Visual_Servoing(resolution_x, resolution_y);
    this->flag_success_ = false;
    this->nh_.getParam("control_rate", this->control_rate_);
    this->nh_.getParam("itera_num_all", this->itera_num_all_);
    this->nh_.getParam("name_link0", this->name_link0_);
    this->nh_.getParam("name_camera_frame", this->name_camera_frame_);
    this->nh_.getParam("name_effector", this->name_effector_);
    this->joint_angle_initial_VS_ = get_parameter_Matrix("joint_angle_initial_VS", 6, 1);
    this->pub_twist_ = this->nh_.advertise<geometry_msgs::Twist>("/twist_controller/command", 5);
    this->image_polarized_sub_ = this->it_.subscribe("camera/polarized_Iall_gray", 1, &Ros_ur_DVS::Callback, this);
    this->start_DVS = false;
    this->goal.trajectory.joint_names.push_back("shoulder_pan_joint");
    this->goal.trajectory.joint_names.push_back("shoulder_lift_joint");
    this->goal.trajectory.joint_names.push_back("elbow_joint");
    this->goal.trajectory.joint_names.push_back("wrist_1_joint");
    this->goal.trajectory.joint_names.push_back("wrist_2_joint");
    this->goal.trajectory.joint_names.push_back("wrist_3_joint");
    this->R_temp_ = Mat::eye(3, 3, CV_64FC1);
    this->p_temp_= Mat::zeros(3, 1, CV_64FC1);
    this->p_so3_temp_= Mat::zeros(3, 3, CV_64FC1);
    this->effector_twist_ = Mat::zeros(6,1,CV_64FC1);
    this->effector_twist_base_ = Mat::zeros(6,1,CV_64FC1);
    this->T_effector_to_base_ = Mat::eye(4, 4, CV_64FC1);
    this->T_camera_to_effector_ = Mat::eye(4, 4, CV_64FC1);
    this->T_camera_to_base_ = Mat::eye(4, 4, CV_64FC1);
    this->px_temp_ = 0; this->py_temp_ = 0; this->pz_temp_ = 0; 

     cv::namedWindow("VS_image", cv::WINDOW_AUTOSIZE);
    // this->client = new Client("pos_joint_traj_controller/follow_joint_trajectory", true);  
    // ROS_INFO("Waiting for action server to start.");
    // this->client->waitForServer();  // ����һֱ�ȴ�ֱ����������������
    // ROS_INFO("Server started, sending goal.");
}



void Ros_ur_DVS::Callback(const ImageConstPtr& image_polar_msg)
{
    if(this->start_DVS)
    {   
        // �����Ӿ��ŷ���ͼ��
        if(~this->get_visual_servoing_image(image_polar_msg, this->VS_image_))
            return;
        // ����ת��
        Mat depth_new, img_new;
        // ��ȡ���λ��
        this->get_camera_pose(this->T_camera_to_base_); 
        // ��������ٶȲ���������
        this->DVS->set_image_depth_current(depth_new);
        this->DVS->set_image_gray_current(img_new); 
        // ׼��
        if(this->DVS->flag_first_)
        {  
            double lambda, epsilon;
            Mat img_old, depth_old, camera_intrinsic, pose_desired;
            // ��ȡ����
            this->get_parameters_DVS(lambda, epsilon, img_old, depth_old, camera_intrinsic, pose_desired);
            this->DVS->init_VS(lambda, epsilon, img_old, depth_old, img_new, camera_intrinsic, pose_desired);
            this->DVS->flag_first_ = false;
        }

        Mat camera_velocity = this->DVS->get_camera_velocity(); 

        this->DVS->save_data(this->T_camera_to_base_);
        // �ж��Ƿ�ɹ������ٶ�ת��
        if(this->DVS->is_success() || this->DVS->iteration_num_ > this->itera_num_all_)
        {
            this->flag_success_ = true;
            this->DVS->write_data();  
            camera_velocity = 0 * camera_velocity;
            this->start_DVS = false;
        }
        else
        {
            this->flag_success_ = false;
            
        }
       // �����ٶ���Ϣ
        this->twist_publist(camera_velocity);
    }
}




bool Ros_ur_DVS::get_visual_servoing_image(const ImageConstPtr& image_polar_msg, cv::Mat& VS_image)
{
        try {
        // ��֤ͼ���ʽ
        if (image_polar_msg->encoding != sensor_msgs::image_encodings::TYPE_8UC4) {
            ROS_INFO("get_visual_servoing_image_cyh_1");
            ROS_WARN_THROTTLE(1.0, "Invalid encoding: %s (expected 8UC4)", 
                            image_polar_msg->encoding.c_str());
            return false;
        }
        ROS_INFO("get_visual_servoing_image_cyh_4");
        // ת��ΪOpenCV��ʽ
        cv_bridge::CvImageConstPtr cv_ptr = cv_bridge::toCvShare(image_polar_msg, sensor_msgs::image_encodings::TYPE_8UC4);
        // �� 8UC4 ת��Ϊ 64FC4
        cv::Mat img_double;
        cv_ptr->image.convertTo(img_double, CV_64FC4); 
        // ���Ϊ�ĸ���ͨ��ͼ��
        std::vector<cv::Mat> channels(4);
        cv::split(img_double, channels);      
        // �����Ӿ��ŷ�����ͼ��
        VS_image = (channels[0] + channels[1] + channels[2] + channels[3]) / 4.0; 
        return true;

    } catch (const cv_bridge::Exception& e) {
        ROS_INFO("get_visual_servoing_image_cyh_2");
        ROS_ERROR("cv_bridge exception: %s", e.what());
        return false;
    } catch (const std::exception& e) {
        ROS_INFO("get_visual_servoing_image_cyh_3");
        ROS_ERROR("Exception: %s", e.what());
        return false;
    }
}



void Ros_ur_DVS::get_camera_pose(Mat& T_camera_to_base)
{
    tf::StampedTransform transform;
    const int max_attempts = 5;
    const double retry_delay = 0.1;
    for (int attempt = 0; attempt < max_attempts; ++attempt)
    {
        try
        {
            // ���Ի�ȡ��ǰʱ�̵ı任
            this->listener_pose_.lookupTransform(this->name_link0_, this->name_camera_frame_, ros::Time(0), this->transform_temp_);
            // this->listener_pose_.lookupTransform("base", "camera_polar_frame", ros::Time(0), transform);
            get_T(this->transform_temp_, T_camera_to_base);  
        }
        catch (tf::TransformException &ex)
        {
            // �����ȡ�任ʧ�ܣ���ӡ������Ϣ�������ȴ�
            ROS_WARN("Failed to get transform, retrying... (%d/%d)", attempt + 1, max_attempts);
            ros::Duration(retry_delay).sleep();
        }
    }
}

void Ros_ur_DVS::twist_publist(Mat camera_velocity)
{
    get_camera_effector_pose(this->T_effector_to_base_, this->T_camera_to_effector_);
    // �ٶ�ת��
    get_effector_twist(camera_velocity, this->T_camera_to_effector_, this->effector_twist_);
    velocity_effector_to_base(this->effector_twist_, this->T_effector_to_base_, this->effector_twist_base_);
    // �����ٶ���Ϣ
    const double* vel_ptr = this->effector_velocity_base_.ptr<double>(0); 
    msg_effector_twist_.linear.x = vel_ptr[0];
    msg_effector_twist_.linear.y = vel_ptr[1];
    msg_effector_twist_.linear.z = vel_ptr[2];
    msg_effector_twist_.angular.x = vel_ptr[3];
    msg_effector_twist_.angular.y = vel_ptr[4];
    msg_effector_twist_.angular.z = vel_ptr[5];
    this->pub_twist_.publish(msg_effector_twist_);
}

void Ros_ur_DVS::get_parameters_resolution(int& resolution_x, int& resolution_y)
{
    this->nh_.getParam("resolution_x", resolution_x);
    this->nh_.getParam("resolution_y", resolution_y);
}

Mat Ros_ur_DVS::get_parameter_Matrix(string str, int row, int col)
{
    Mat Matrix;
    XmlRpc::XmlRpcValue param_yaml;
    this->nh_.getParam(str, param_yaml);
    double data[param_yaml.size()];
    for(int i=0; i<param_yaml.size(); i++) 
    {
        data[i] = param_yaml[i];
    }
    Mat Matrix_temp = Mat(row, col, CV_64FC1, data);
    Matrix_temp.copyTo(Matrix);   
    return Matrix;
}



void Ros_ur_DVS::get_parameters_DVS(double& lambda, double& epsilon, Mat& image_gray_desired, Mat& image_depth_desired, Mat& camera_intrinsic, Mat& pose_desired)
{
    // ��������
    this->nh_.getParam("lambda", lambda);
    this->nh_.getParam("epsilon", epsilon);
    // ͼ�����
    string loaction, name;
    this->nh_.getParam("resource_location", loaction);
    // ����ɫͼ
    this->nh_.getParam("image_rgb_desired_name", name);
    Mat image_rgb_desired = imread(loaction + name, IMREAD_COLOR);
    rgb_image_operate(image_rgb_desired, image_gray_desired);  
    // ��ֵ���ͼ
    double depth_desired;
    this->nh_.getParam("depth_desired", depth_desired);
    image_depth_desired = Mat::ones(image_rgb_desired.size(), CV_64F) * 1.5;
    // ����ڲ�
    camera_intrinsic = get_parameter_Matrix("camera_intrinsic", 3, 3);
    // ����λ��
    pose_desired = get_parameter_Matrix("pose_desired", 4, 4);
}



void Ros_ur_DVS::rgb_image_operate(Mat& image_rgb, Mat& image_gray)
{
    Mat temp_gray;
    cvtColor(image_rgb, temp_gray, cv::COLOR_BGR2GRAY);
    temp_gray.convertTo(image_gray, CV_64FC1);
}


void Ros_ur_DVS::get_T(tf::StampedTransform  transform, Mat& T)
{
    tf::Matrix3x3 rotation_matrix = transform.getBasis();
    tf::Vector3 translation_vector = transform.getOrigin();

    T.at<double>(0, 3) = translation_vector[0];
    T.at<double>(1, 3) = translation_vector[1];
    T.at<double>(2, 3) = translation_vector[2];

    T.at<double>(0, 0) = rotation_matrix[0][0]; T.at<double>(0, 1) = rotation_matrix[0][1]; T.at<double>(0, 2) = rotation_matrix[0][2];
    T.at<double>(1, 0) = rotation_matrix[1][0]; T.at<double>(1, 1) = rotation_matrix[1][1]; T.at<double>(1, 2) = rotation_matrix[1][2];
    T.at<double>(2, 0) = rotation_matrix[2][0]; T.at<double>(2, 1) = rotation_matrix[2][1]; T.at<double>(2, 2) = rotation_matrix[2][2];
}


void Ros_ur_DVS::robot_move_to_target_joint_angle(std::vector<double> joint_group_positions_target)
{
   // ���ӹ켣��
    trajectory_msgs::JointTrajectoryPoint point;
    point.positions.resize(6); 
    for (int i=0; i<6; i++)
        point.positions[i] = joint_group_positions_target[i];
    point.time_from_start = ros::Duration(5.0);
    this->goal.trajectory.points.clear();
    this->goal.trajectory.points.push_back(point);
    this->goal.trajectory.header.stamp = ros::Time::now(); 
    this->client->sendGoal(goal);
    // �ȴ����
    bool finished_before_timeout = this->client->waitForResult(ros::Duration(6.0));

    if (finished_before_timeout)
    {
        actionlib::SimpleClientGoalState state = this->client->getState();
        ROS_INFO("Action finished: %s", state.toString().c_str());
    }
    else
        ROS_INFO("Action did not finish before the time out.");
}


void Ros_ur_DVS::get_camera_effector_pose(Mat& T_effector_to_base, Mat& T_camera_to_effector)
{
    tf::StampedTransform transform;
    const int max_attempts = 5;
    const double retry_delay = 0.1;
    for (int attempt = 0; attempt < max_attempts; ++attempt)
    {
        try
        {
            tf::StampedTransform transform; //"base" "tool0_controller" "camera_polar_frame"
            // ���Ի�ȡ��ǰʱ�̵ı任
            this->listener_pose_.lookupTransform(this->name_link0_, this->name_effector_, ros::Time(0), this->transform_temp_);
            this->get_T(this->transform_temp_, T_effector_to_base);

            this->listener_pose_.lookupTransform(this->name_effector_, this->name_camera_frame_, ros::Time(0), this->transform_temp_);
            this->get_T(this->transform_temp_, T_camera_to_effector);  
        }
        catch (tf::TransformException &ex)
        {
            // �����ȡ�任ʧ�ܣ���ӡ������Ϣ�������ȴ�
            ROS_WARN("Failed to get transform, retrying... (%d/%d)", attempt + 1, max_attempts);
            ros::Duration(retry_delay).sleep();
        }
    }
}

void Ros_ur_DVS::get_effector_twist(const Mat& camera_velocity, const Mat& T_camera_to_effector, Mat& effector_twist)
{
    this->R_temp_ = T_camera_to_effector(cv::Rect(0, 0, 3, 3));
    this->p_temp_ = T_camera_to_effector(cv::Rect(3, 0, 1, 3));
    this->px_temp_ = this->p_temp_.at<double>(0);
    this->py_temp_ = this->p_temp_.at<double>(1);
    this->pz_temp_ = this->p_temp_.at<double>(2);

    this->p_so3_temp_.at<double>(0,1) = -this->pz_temp_;  this->p_so3_temp_.at<double>(0,2) = this->py_temp_;
    this->p_so3_temp_.at<double>(1,0) = this->pz_temp_;   this->p_so3_temp_.at<double>(1,2) = -this->px_temp_;
    this->p_so3_temp_.at<double>(2,0) = -this->py_temp_;  this->p_so3_temp_.at<double>(2,1) = this->px_temp_;   

    effector_twist.rowRange(0,3).colRange(0,1) = this->R_temp_ * camera_velocity.rowRange(0,3).colRange(0,1) + 
                        this->p_so3_temp_ * this->R_temp_ * camera_velocity.rowRange(3,6).colRange(0,1);                   
    effector_twist.rowRange(3,6).colRange(0,1) = this->R_temp_ * camera_velocity.rowRange(3,6).colRange(0,1);
}

void Ros_ur_DVS::velocity_effector_to_base(const Mat& velocity, const Mat& effector_to_base, Mat& effector_twist_bast)
{
    effector_twist_bast.rowRange(0,3).colRange(0,1) = effector_to_base.rowRange(0,3).colRange(0,3) * velocity.rowRange(0,3).colRange(0,1);
    effector_twist_bast.rowRange(3,6).colRange(0,1) = effector_to_base.rowRange(0,3).colRange(0,3) * velocity.rowRange(3,6).colRange(0,1);
}